from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__)

# Load the model
model = joblib.load('model_joblib_diabetes')

@app.route('/')


def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get data from form
    pregnancies = float(request.form['pregnancies'])
    glucose = float(request.form['glucose'])
    blood_pressure = float(request.form['bloodpressure'])  # Corrected
    skin_thickness = float(request.form['skinthickness'])  # Corrected
    insulin = float(request.form['insulin'])
    bmi = float(request.form['bmi'])
    pedigree_function = float(request.form['diabetespedigree'])  # Corrected
    age = float(request.form['age'])

    # Prepare the input data for prediction
    input_data = pd.DataFrame([[pregnancies, glucose, blood_pressure, skin_thickness,
                                insulin, bmi, pedigree_function, age]],
                              columns=['Pregnancies', 'Glucose', 'BloodPressure',
                                       'SkinThickness', 'Insulin', 'BMI',
                                       'DiabetesPedigreeFunction', 'Age'])

    # Make the prediction
    prediction = model.predict(input_data)

    result = 'Diabetic' if prediction[0] == 1 else 'Non-Diabetic'
    return render_template('result.html', prediction=result)

if __name__ == '__main__':
    app.run(debug=True)






